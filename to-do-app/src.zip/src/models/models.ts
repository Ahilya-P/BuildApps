export interface Todo {
  id: number;
  todo: string;
  isDone: boolean;
}
